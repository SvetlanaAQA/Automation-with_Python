from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
#from authodata import vk_password
import time

options = webdriver.ChromeOptions()
# Добавьте опции, если необходимо, например:
# options.add_argument("--headless")  # Запуск в безголовом режиме

try:
    url = "https://vk.com"
    browser = webdriver.Chrome(options=options)
    browser.get(url)

    email_input = browser.find_element(By.ID,"index_email")
    email_input.clear()
    email_input.send_keys("37358550840")

    #password_input = browser.find_element(By.ID,"index_pass")
    #password_input.clear()
    #password_input.send_keys(vk_password)

    login_button =  browser.find_element(By.ID, "index_login").click()

    # Можно добавить дополнительную задержку, если это необходимо
    time.sleep(60)

except Exception as ex:
    print(ex)
finally:
    # Закрываем браузер после использования
    if 'browser' in locals():
        browser.quit()