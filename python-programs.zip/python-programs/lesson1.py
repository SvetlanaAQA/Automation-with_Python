import os

print("Hello World")

fileName = "lesson2.py"
if not os.path.exists(fileName):
    os.mknod(fileName)
    print("File Created")
else:
    print("file already exist")