def requestUserInput(message):
    value = input(message)
    while not value:
        value = input(message)
    return value



def Groceries():
    productName = requestUserInput("Enter name:")
    weight = float(requestUserInput("Enter weight (g): "))
    protein = float(requestUserInput("Enter protein per 100g: "))
    fat = float(requestUserInput("Enter fat per 100g: "))
    carbs = float(requestUserInput("Enter carbs per 100g: "))
    totalProtein = weight * protein / 100
    totalFat = weight * fat / 100
    totalCarbs = weight * carbs / 100
    totalEnergy = totalProtein * 4 + totalFat * 9 + totalCarbs * 4
    print(productName  +", Energy: " + str(totalEnergy) + "Kcal")
    print("Protein: " + str(totalProtein) + "g")
    print("Fat: "+ str(totalFat) + "g")
    print("Carbs: "+ str(totalCarbs) + "g")       

Groceries()

