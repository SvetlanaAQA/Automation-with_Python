def requestUserInput(message):
    value = input(message)
    while not value:
        value = input(message)
    return value
    

def requestUserInputFloat (message):
    while True:
        value = requestUserInput(message)
        try:
            return float(value)
        except ValueError:
            print ("You need input number")
 
   
def Groceries():
    productName = requestUserInput("Enter name:")
    weight = requestUserInputFloat ("Enter weight (g): ")
    protein = requestUserInputFloat("Enter protein per 100g: ")
    fat = requestUserInputFloat("Enter fat per 100g: ")
    carbs = requestUserInputFloat("Enter carbs per 100g: ")
    totalProtein = weight * protein / 100
    totalFat = weight * fat / 100
    totalCarbs = weight * carbs / 100
    totalEnergy = totalProtein * 4 + totalFat * 9 + totalCarbs * 4
    print(productName  +", Energy: " + str(totalEnergy) + "Kcal")
    print("Protein: " + str(totalProtein) + "g")
    print("Fat: "+ str(totalFat) + "g")
    print("Carbs: "+ str(totalCarbs) + "g")       

Groceries()
